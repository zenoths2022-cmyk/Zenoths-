// ZENOTHS website content. Batch editors can update this file on GitHub.
window.ZENOTHS_DATA = {
  ongoing: [
    // Add items like: { title: "Sports Week", date: "Dec 10–12", description: "Live updates and highlights.", link: "https://example.com" }
  ],
  upcoming: [
    // Add items like: { title: "Annual Day", date: "Jan 2027", description: "Event details and announcements.", link: "https://example.com" }
  ],
  gallery: [
    // Upload each image to the repository root or a folder, then add: { src: "photos/sports-day.jpg", alt: "Sports day" }
  ],
  instagram: {
    zenoths: "https://www.instagram.com/_.zenoths._/",
    college: "https://www.instagram.com/kgf_dental_college_official/"
  }
};
